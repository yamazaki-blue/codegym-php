<?php
$nums = [100, 5, 2, -10, 8, 10, -1, 15, 1, -100];

$idxLast = count($nums) - 1;

//ここにコードを書きましょう。

echo '<pre>';
print_r($nums);
echo '</pre>';

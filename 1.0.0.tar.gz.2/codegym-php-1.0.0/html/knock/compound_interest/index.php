<?php
$principal = 400000; //元金
$rate = 0.5;//金利
$length = 40; //年数

echo '0年目：' . $principal . '円' . PHP_EOL;

//ここにコードを書きましょう。
